<template>
<div>
<input v-model="date" type="date"/>
<input v-model="time" type="time"/>
<input v-model="cep" placeholder="CEP"/>
<button @click="schedule">Agendar</button>
</div>
</template>

<script>
import api from '../services/api'

export default {
data(){ return {date:'', time:'', cep:''}},
methods:{
async schedule(){
await api.post('/appointments',
{date:this.date,time:this.time,cep:this.cep},
{headers:{Authorization:localStorage.getItem('token')}})
}
}}
</script>