const mongoose = require('mongoose')

const AppointmentSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  date: String,
  time: String,
  cep: String,
  address: String,
  weather: String
})

module.exports = mongoose.model('Appointment', AppointmentSchema)