require('dotenv').config()
const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')

const app = express()
app.use(cors())
app.use(express.json())

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB conectado"))

app.use('/auth', require('./routes/authRoutes'))
app.use('/appointments', require('./routes/appointmentRoutes'))

app.listen(3000, () => console.log("Servidor rodando"))